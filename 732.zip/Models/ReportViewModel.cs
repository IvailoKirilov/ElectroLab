﻿namespace ElectroLab.Models
{
    public class ReportViewModel
    {
        public int ReportId { get; set; }               
        public string ReportContent { get; set; }       
        public string ReporterUserName { get; set; }    
        public string ReportType { get; set; }          
    }
}

